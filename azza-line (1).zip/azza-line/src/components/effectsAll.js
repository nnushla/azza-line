// Re-export everything from effects.js with the rainbow variant properly exported.
// This file exists because StopModal and easterEggs both need fireRainbowConfetti,
// but we want to keep effects.js clean.

export { fireConfetti, showToast, ToastContainer } from './effects.js';

export function fireRainbowConfetti() {
  const pieces = ['🌈', '🏳️‍🌈', '💜', '💛', '💚', '💙', '🌸', '✨'];
  const container = document.getElementById('confetti-root');
  if (!container) return;
  for (let i = 0; i < 60; i++) {
    setTimeout(() => {
      const el = document.createElement('div');
      el.style.cssText = `
        position: fixed; pointer-events: none; z-index: 9999;
        left: ${Math.random() * 100}vw; top: -30px;
        font-size: ${0.8 + Math.random() * 1.2}rem;
        animation: confettiFall ${2 + Math.random() * 3}s ease forwards;
        animation-delay: ${Math.random() * 0.5}s;
      `;
      el.textContent = pieces[Math.floor(Math.random() * pieces.length)];
      container.appendChild(el);
      setTimeout(() => el.remove(), 5000);
    }, i * 40);
  }
}
