import { useEffect, useRef } from 'react';
import { fireConfetti, fireRainbowConfetti, showToast } from './effectsAll.js';

// ── KONAMI CODE ──────────────────────────────────────────────
const KONAMI = ['ArrowUp','ArrowUp','ArrowDown','ArrowDown','ArrowLeft','ArrowRight','ArrowLeft','ArrowRight','b','a'];

// activateUltimateMusicNerdMode — creates an overlay
function activateUltimateMusicNerdMode() {
  showToast('🎵 ULTIMATE MUSIC NERD MODE UNLOCKED! 🎵', 5000);
  fireRainbowConfetti();

  // Briefly rainbow the body
  document.body.style.animation = 'rainbow 0.5s linear infinite';
  setTimeout(() => { document.body.style.animation = ''; }, 4000);

  // Create full-screen overlay
  if (document.getElementById('mnm-overlay')) return;
  const overlay = document.createElement('div');
  overlay.id = 'mnm-overlay';
  overlay.style.cssText = `
    position:fixed;inset:0;background:rgba(0,0,0,0.92);z-index:9000;
    display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1.5rem;
    font-family:'Space Grotesk',sans-serif;
  `;
  overlay.innerHTML = `
    <div style="font-family:'Abril Fatface',serif;font-size:2.5rem;color:#FCE03E;text-align:center;animation:pulse 1s infinite;">
      🎵 ULTIMATE MUSIC NERD MODE 🎵
    </div>
    <div style="color:white;font-size:1rem;text-align:center;max-width:400px;line-height:1.6;padding:0 1.5rem;">
      Unlocked via the Konami Code.<br>
      Only the most devoted music nerds know this.<br>
      Azza would know this.
    </div>
    <div style="display:flex;gap:0.75rem;flex-wrap:wrap;justify-content:center;">
      <div onclick="document.getElementById('mnm-overlay').dataset.toast='song'" style="background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);border-radius:12px;padding:0.875rem 1.25rem;color:white;text-align:center;cursor:pointer;">
        <div style="font-size:1.5rem;">🎵</div>
        <div style="font-size:0.8rem;margin-top:0.25rem;">Guess The Song</div>
      </div>
      <div onclick="document.getElementById('mnm-overlay').dataset.toast='trivia'" style="background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);border-radius:12px;padding:0.875rem 1.25rem;color:white;text-align:center;cursor:pointer;">
        <div style="font-size:1.5rem;">🎸</div>
        <div style="font-size:0.8rem;margin-top:0.25rem;">Music Trivia</div>
      </div>
    </div>
    <button id="mnm-close" style="background:white;color:#0A0E2E;border:none;padding:0.75rem 2rem;border-radius:12px;font-weight:700;cursor:pointer;font-family:'Space Grotesk',sans-serif;font-size:1rem;">
      Close
    </button>
  `;
  document.body.appendChild(overlay);

  document.getElementById('mnm-close').addEventListener('click', () => overlay.remove());

  // Handle mini-game clicks
  overlay.addEventListener('click', e => {
    const toast = overlay.dataset.toast;
    if (toast === 'song') showToast('🎵 This is the song she played you that changed your life.');
    if (toast === 'trivia') showToast('🎸 Azza wins the music quiz. Every time.');
    delete overlay.dataset.toast;
  });
}

// ── EASTER EGG HOOK ──────────────────────────────────────────
// Drop this in App.jsx: useEasterEggs()
export function useEasterEggs() {
  const konamiRef = useRef([]);
  const bufferRef = useRef('');

  useEffect(() => {
    const handler = (e) => {
      // ── Konami code ─────────────────────────
      konamiRef.current.push(e.key);
      if (konamiRef.current.length > KONAMI.length) konamiRef.current.shift();
      if (JSON.stringify(konamiRef.current) === JSON.stringify(KONAMI)) {
        activateUltimateMusicNerdMode();
      }

      // ── Typed easter eggs ────────────────────
      // Only track printable chars to avoid cluttering with arrow keys etc.
      if (e.key.length === 1) {
        bufferRef.current = (bufferRef.current + e.key).slice(-30);
        const buf = bufferRef.current.toUpperCase();

        if (buf.includes("I'M GAY") || buf.includes("IM GAY")) {
          fireRainbowConfetti();
          showToast("We know. 🏳️‍🌈 We're proud of you.", 4000);
          bufferRef.current = '';
        } else if (buf.includes('BAGEL')) {
          showToast('🥯 You gained +5 NYC credibility.');
          bufferRef.current = '';
        }
      }
    };

    // ── Double-click bagel ───────────────────
    const dblClickHandler = (e) => {
      if (e.target?.textContent?.includes('🥯')) {
        showToast('🥯 You gained +5 NYC credibility.');
      }
    };

    window.addEventListener('keydown', handler);
    window.addEventListener('dblclick', dblClickHandler);
    return () => {
      window.removeEventListener('keydown', handler);
      window.removeEventListener('dblclick', dblClickHandler);
    };
  }, []);
}
