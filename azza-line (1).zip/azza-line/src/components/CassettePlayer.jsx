import React, { useState } from 'react';
import { SPOTIFY_EMBED_URL } from '../data/azza.js';

export default function CassettePlayer() {
  const [minimized, setMinimized] = useState(false);

  return (
    <div style={{
      position: 'fixed',
      bottom: '1.5rem',
      right: '1.5rem',
      zIndex: 500,
      width: minimized ? '56px' : '300px',
      height: minimized ? '56px' : 'auto',
      borderRadius: minimized ? '50%' : '20px',
      background: '#1a1a2e',
      border: '2px solid rgba(255,255,255,0.1)',
      boxShadow: '0 16px 48px rgba(0,0,0,0.4)',
      transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
      overflow: 'hidden',
    }}>
      {minimized ? (
        /* Minimized pill — just the green button */
        <button
          onClick={() => setMinimized(false)}
          aria-label="Open music player"
          style={{
            position: 'absolute',
            inset: 0,
            background: '#1DB954',
            border: 'none',
            borderRadius: '50%',
            color: 'white',
            fontSize: '1.5rem',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          🎵
        </button>
      ) : (
        <>
          {/* Header */}
          <div
            role="button"
            tabIndex={0}
            onClick={() => setMinimized(true)}
            onKeyDown={e => e.key === 'Enter' && setMinimized(true)}
            style={{
              padding: '0.75rem 1rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              borderBottom: '1px solid rgba(255,255,255,0.1)',
              cursor: 'pointer',
            }}
          >
            <div style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              background: '#1DB954',
              animation: 'pulse 1.5s infinite',
              flexShrink: 0,
            }} />
            <div style={{ flex: 1 }}>
              <div style={{ color: 'white', fontSize: '0.8rem', fontWeight: 600 }}>
                25 Songs That Remind Us of You
              </div>
              <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.65rem' }}>
                click to minimize
              </div>
            </div>
            <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.9rem' }}>▼</span>
          </div>

          {/* Spotify embed */}
          <div style={{ padding: '0.75rem' }}>
            <iframe
              style={{ borderRadius: '10px', display: 'block' }}
              src={SPOTIFY_EMBED_URL}
              width="100%"
              height="200"
              frameBorder="0"
              allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
              loading="lazy"
              title="25 Songs That Remind Us of You — Azza's Birthday Playlist"
            />
          </div>
        </>
      )}
    </div>
  );
}
