import React from 'react';
import { STOPS } from '../data/stops.js';

export default function SubwayMap({ visited, onSelectStop, onGoToFinale }) {
  const visitedCount = visited.size;

  return (
    <div style={{ minHeight: '100vh', background: 'var(--cream)' }}>
      {/* Sticky header */}
      <div style={{
        background: 'var(--navy)',
        color: 'white',
        padding: '1.25rem 2rem',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '1rem',
        position: 'sticky',
        top: 0,
        zIndex: 100,
      }}>
        <div>
          <div style={{
            fontFamily: "'Space Mono', monospace",
            fontSize: '0.65rem',
            letterSpacing: '2px',
            color: 'rgba(255,255,255,0.5)',
            marginBottom: '2px',
          }}>
            THE A-ZZA LINE
          </div>
          <h1 style={{
            fontFamily: "'Abril Fatface', serif",
            fontSize: '1.5rem',
            color: 'var(--metro-yellow)',
          }}>
            25 Stops to Azza 🚇
          </h1>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
          <div style={{
            background: 'rgba(255,255,255,0.1)',
            border: '1px solid rgba(255,255,255,0.2)',
            borderRadius: '99px',
            padding: '0.4rem 1rem',
            fontFamily: "'Space Mono', monospace",
            fontSize: '0.8rem',
            color: 'white',
          }}>
            {visitedCount} / 25 Stops Visited
          </div>
          <button
            onClick={onGoToFinale}
            style={{
              background: 'var(--metro-yellow)',
              color: 'var(--navy)',
              border: 'none',
              padding: '0.5rem 1rem',
              borderRadius: '12px',
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: '0.85rem',
              fontWeight: 700,
              cursor: 'pointer',
            }}
          >
            🎂 Final Stop
          </button>
        </div>
      </div>

      {/* Stop list */}
      <div style={{ padding: '2rem 1rem', maxWidth: '800px', margin: '0 auto' }}>
        <div style={{
          fontFamily: "'Space Mono', monospace",
          fontSize: '0.7rem',
          letterSpacing: '3px',
          color: 'var(--muted)',
          textTransform: 'uppercase',
          marginBottom: '1rem',
          paddingLeft: '1rem',
        }}>
          🚇 A-ZZA Train · Uptown & The Bronx of Azza's Heart
        </div>

        <div style={{ position: 'relative', paddingLeft: '60px' }}>
          {/* Track line */}
          <div style={{
            position: 'absolute',
            left: '32px',
            top: 0,
            bottom: 0,
            width: '4px',
            background: 'linear-gradient(to bottom, var(--metro-yellow), #ff6eb4, #6eb5ff, var(--metro-yellow))',
            borderRadius: '4px',
          }} />

          {STOPS.map((stop, i) => {
            const isVisited = visited.has(i);
            return (
              <div
                key={i}
                style={{
                  position: 'relative',
                  marginBottom: '0.75rem',
                  animation: `slideUp 0.5s ${i * 0.03}s ease both`,
                }}
              >
                {/* Dot on track */}
                <div style={{
                  position: 'absolute',
                  left: '-38px',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  width: '20px',
                  height: '20px',
                  borderRadius: '50%',
                  background: isVisited ? 'var(--metro-yellow)' : 'white',
                  border: '3px solid var(--metro-yellow)',
                  zIndex: 2,
                  transition: 'background 0.3s',
                }} />

                <button
                  onClick={() => onSelectStop(i)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.75rem',
                    padding: '0.75rem 1rem',
                    background: isVisited ? '#fffde8' : 'white',
                    border: `1.5px solid ${isVisited ? 'var(--metro-yellow)' : 'var(--border)'}`,
                    borderRadius: '12px',
                    cursor: 'pointer',
                    width: '100%',
                    textAlign: 'left',
                    transition: 'all 0.2s',
                    fontFamily: "'Space Grotesk', sans-serif",
                  }}
                  onMouseEnter={e => {
                    e.currentTarget.style.transform = 'translateX(4px)';
                    e.currentTarget.style.borderColor = 'var(--metro-yellow)';
                    e.currentTarget.style.boxShadow = '0 4px 16px rgba(252,224,62,0.2)';
                  }}
                  onMouseLeave={e => {
                    e.currentTarget.style.transform = '';
                    e.currentTarget.style.borderColor = isVisited ? 'var(--metro-yellow)' : 'var(--border)';
                    e.currentTarget.style.boxShadow = '';
                  }}
                  aria-label={`Stop ${i + 1}: ${stop.name}${isVisited ? ' (visited)' : ''}`}
                >
                  <span style={{
                    fontFamily: "'Space Mono', monospace",
                    fontSize: '0.7rem',
                    color: 'var(--muted)',
                    minWidth: '28px',
                  }}>
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <span style={{ fontSize: '1.2rem' }}>{stop.emoji}</span>
                  <span style={{ fontWeight: 600, fontSize: '0.95rem', flex: 1 }}>{stop.name}</span>
                  <span style={{ fontSize: '0.75rem', color: 'var(--muted)' }}>{stop.short}</span>
                  {isVisited && (
                    <span style={{ color: 'var(--spotify-green)', fontSize: '1.1rem' }}>✓</span>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
