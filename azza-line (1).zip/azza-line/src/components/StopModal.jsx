import React, { useEffect, useRef } from 'react';
import { STOPS } from '../data/stops.js';
import { fireConfetti, showToast } from './effectsAll.js';
import PhotoOrEmoji from './PhotoOrEmoji.jsx';
import {
  FRIENDS, BANGS_ERAS, CONCERTS, ALBUMS, DEEP_CUTS,
  PLAYLISTS, LOVE_LETTERS, FINALE_MESSAGES, MUSIC_TIMELINE, HOT_TAKES,
} from '../data/azza.js';

// ─────────────────────────────────────────────────────────────
//  STOP MODAL SHELL
// ─────────────────────────────────────────────────────────────
export default function StopModal({ stopIndex, onClose, onPrev, onNext }) {
  const stop = STOPS[stopIndex];
  const isFirst = stopIndex === 0;
  const isLast = stopIndex === STOPS.length - 1;

  // Trap focus & ESC key
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') onNext();
      if (e.key === 'ArrowLeft') onPrev();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose, onNext, onPrev]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-stop-title"
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 1000,
        background: 'rgba(10,14,46,0.85)',
        backdropFilter: 'blur(4px)',
        overflowY: 'auto',
        padding: '1rem',
        display: 'flex',
        alignItems: 'flex-start',
        justifyContent: 'center',
      }}
    >
      <div style={{
        background: 'var(--card-bg)',
        borderRadius: '24px',
        maxWidth: '680px',
        width: '100%',
        margin: 'auto',
        padding: '2rem',
        position: 'relative',
        animation: 'slideUp 0.4s ease',
        border: '2px solid var(--border)',
      }}>
        {/* Close button */}
        <button
          onClick={onClose}
          aria-label="Close stop"
          style={{
            position: 'absolute',
            top: '1rem',
            right: '1rem',
            background: 'var(--navy)',
            color: 'white',
            border: 'none',
            borderRadius: '50%',
            width: '36px',
            height: '36px',
            fontSize: '1rem',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transition: 'transform 0.15s',
          }}
          onMouseEnter={e => { e.currentTarget.style.transform = 'rotate(90deg) scale(1.1)'; }}
          onMouseLeave={e => { e.currentTarget.style.transform = ''; }}
        >✕</button>

        {/* Stop header */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1.5rem' }}>
          <span style={{ fontSize: '2rem' }}>{stop.emoji}</span>
          <div>
            <div style={{
              background: 'var(--metro-yellow)',
              color: 'var(--navy)',
              fontFamily: "'Space Mono', monospace",
              fontSize: '0.65rem',
              letterSpacing: '2px',
              padding: '2px 10px',
              borderRadius: '99px',
              fontWeight: 700,
              display: 'inline-block',
              marginBottom: '0.25rem',
            }}>
              STOP {String(stopIndex + 1).padStart(2, '0')}
            </div>
            <h2 id="modal-stop-title" style={{
              fontFamily: "'Abril Fatface', serif",
              fontSize: '1.6rem',
              color: 'var(--ink)',
              lineHeight: 1.1,
            }}>{stop.name}</h2>
          </div>
        </div>

        {/* Stop content */}
        <StopContent index={stopIndex} />

        {/* Nav buttons */}
        <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1.5rem', flexWrap: 'wrap', alignItems: 'center' }}>
          <NavBtn onClick={onPrev} disabled={isFirst}>← Prev Stop</NavBtn>
          <NavBtn onClick={onNext}>{isLast ? '🎉 Done!' : 'Next Stop →'}</NavBtn>
          <button
            onClick={onClose}
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--muted)', fontSize: '0.85rem', textDecoration: 'underline' }}
          >Back to Map</button>
        </div>
      </div>
    </div>
  );
}

function NavBtn({ onClick, disabled, children }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        background: disabled ? '#ccc' : 'var(--navy)',
        color: 'white',
        border: 'none',
        padding: '0.75rem 1.5rem',
        borderRadius: '12px',
        fontFamily: "'Space Grotesk', sans-serif",
        fontSize: '0.95rem',
        fontWeight: 600,
        cursor: disabled ? 'default' : 'pointer',
        opacity: disabled ? 0.4 : 1,
        transition: 'all 0.2s',
      }}
      onMouseEnter={e => { if (!disabled) { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = '0 8px 20px rgba(0,0,0,0.2)'; }}}
      onMouseLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.boxShadow = ''; }}
    >
      {children}
    </button>
  );
}

// ─────────────────────────────────────────────────────────────
//  ROUTER — picks which stop to render
// ─────────────────────────────────────────────────────────────
function StopContent({ index }) {
  switch (index) {
    case 0:  return <StopBangs />;
    case 1:  return <StopMusicOrigin />;
    case 2:  return <StopCoffee />;
    case 3:  return <StopCouncil />;
    case 4:  return <StopNYCLove />;
    case 5:  return <StopPlaylists />;
    case 6:  return <StopGayBingo />;
    case 7:  return <Stop3AM />;
    case 8:  return <StopMercury />;
    case 9:  return <StopDeepCuts />;
    case 10: return <StopGeminiCourt />;
    case 11: return <StopSpringEnergy />;
    case 12: return <StopNYCSim />;
    case 13: return <StopConcerts />;
    case 14: return <StopHotTakes />;
    case 15: return <StopNightSky />;
    case 16: return <StopMongolia />;
    case 17: return <StopBodegaCat />;
    case 18: return <StopAlbums />;
    case 19: return <StopWiki />;
    case 20: return <StopQuarterCentury />;
    case 21: return <StopLoveLetters />;
    case 22: return <StopFiller emoji="🍕" title="Midnight Slice Spot" desc="Fold the pizza. Don't let anyone tell you otherwise. NYC religion." />;
    case 23: return <StopFiller emoji="🥯" title="Bagel Break" desc="Double-click a bagel for +5 NYC credibility. You've earned it." />;
    case 24: return <StopFinale />;
    default: return <StopFiller emoji="✨" title="Coming soon!" desc="This stop is still being decorated with love." />;
  }
}

// ─────────────────────────────────────────────────────────────
//  STOP 1 — BANGS HALL OF FAME
// ─────────────────────────────────────────────────────────────
function StopBangs() {
  return (
    <>
      <Muted>A chronological study of the most iconic bangs in recorded history. Scientists are still analyzing.</Muted>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(120px, 1fr))', gap: '1rem', marginBottom: '1.25rem' }}>
        {BANGS_ERAS.map((b, i) => (
          <div key={i} className="bangs-card" style={{
            background: 'white',
            border: '1.5px solid var(--border)',
            borderRadius: '12px',
            padding: '0.75rem',
            textAlign: 'center',
            cursor: 'default',
            transition: 'transform 0.2s',
          }}
            onMouseEnter={e => { e.currentTarget.style.transform = 'rotate(-2deg) scale(1.05)'; }}
            onMouseLeave={e => { e.currentTarget.style.transform = ''; }}
          >
            {/* Photo or emoji */}
            <PhotoOrEmoji
              src={b.photo}
              emoji={b.emoji}
              alt={`Bangs era: ${b.era}`}
              height="100px"
              style={{ marginBottom: '0.5rem', borderRadius: '8px' }}
            />
            <div style={{ fontWeight: 600, fontSize: '0.75rem', color: 'var(--navy)' }}>{b.era}</div>
            <div style={{ fontSize: '0.65rem', color: 'var(--muted)' }}>{b.rating}</div>
          </div>
        ))}
      </div>
      <Divider>verdict</Divider>
      <div style={{ background: 'var(--navy)', color: 'white', borderRadius: '12px', padding: '1rem 1.25rem', textAlign: 'center' }}>
        <span style={{ fontSize: '1.5rem' }}>✂️</span>
        <p style={{ fontStyle: 'italic', marginTop: '0.5rem', fontSize: '1rem' }}>"Nobody has committed harder to a fringe."</p>
        <p style={{ fontSize: '0.75rem', opacity: 0.5, marginTop: '0.25rem', fontFamily: "'Space Mono', monospace" }}>— The Hair Hall of Fame, 2024</p>
      </div>
      <PhotoNote>Add photos in <code>public/images/bangs/</code> and set paths in <code>src/data/azza.js</code></PhotoNote>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 2 — MUSIC ORIGIN STORY
// ─────────────────────────────────────────────────────────────
function StopMusicOrigin() {
  return (
    <>
      <Muted>Every music nerd has an origin story. Here's yours.</Muted>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
        {MUSIC_TIMELINE.map((m, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: '1rem',
            background: 'white', border: '1.5px solid var(--border)',
            borderRadius: '12px', padding: '0.875rem',
          }}>
            <span style={{ fontSize: '1.5rem' }}>{m.icon}</span>
            <div>
              <div style={{ fontFamily: "'Space Mono', monospace", fontSize: '0.7rem', color: 'var(--muted)' }}>{m.year}</div>
              <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>{m.event}</div>
            </div>
          </div>
        ))}
      </div>
      <PhotoNote>Edit milestones in <code>src/data/azza.js</code> → MUSIC_TIMELINE</PhotoNote>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 3 — ICED COFFEE HOURS
// ─────────────────────────────────────────────────────────────
function StopCoffee() {
  return (
    <>
      <Muted>The iced coffee consumption has been studied and documented.</Muted>
      <div style={{ textAlign: 'center', padding: '1.5rem' }}>
        <span style={{ fontSize: '5rem' }}>☕</span>
        <div style={{ fontFamily: "'Abril Fatface', serif", fontSize: '3rem', color: 'var(--navy)', margin: '0.5rem 0' }}>∞</div>
        <div style={{ fontSize: '0.9rem', color: 'var(--muted)' }}>estimated cups consumed</div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
        {[
          { icon: '🥛', label: 'Oat milk, always', sub: 'Non-negotiable' },
          { icon: '🧊', label: 'Extra ice', sub: 'Summer or winter' },
        ].map(c => (
          <div key={c.label} style={{ background: 'white', border: '1.5px solid var(--border)', borderRadius: '12px', padding: '1rem', textAlign: 'center' }}>
            <div style={{ fontSize: '1.5rem', marginBottom: '0.25rem' }}>{c.icon}</div>
            <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>{c.label}</div>
            <div style={{ fontSize: '0.75rem', color: 'var(--muted)' }}>{c.sub}</div>
          </div>
        ))}
      </div>
      <PhotoNote>Customize Azza's actual coffee order in <code>src/data/azza.js</code></PhotoNote>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 4 — BROWN FRIEND COUNCIL
// ─────────────────────────────────────────────────────────────
function StopCouncil() {
  return (
    <>
      <Muted>The most powerful council in the known world. Brown girl magic, assembled.</Muted>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: '1rem' }}>
        {FRIENDS.map((f, i) => (
          <div key={i} style={{
            background: 'white', border: '1.5px solid var(--border)',
            borderRadius: '16px', padding: '1.25rem', textAlign: 'center',
            cursor: 'pointer', transition: 'all 0.2s',
          }}
            onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = '0 8px 24px rgba(0,0,0,0.1)'; }}
            onMouseLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.boxShadow = ''; }}
          >
            <div style={{ width: '64px', height: '64px', margin: '0 auto 0.75rem', borderRadius: '50%', overflow: 'hidden' }}>
              <PhotoOrEmoji
                src={f.photo}
                emoji={f.emoji}
                alt={f.name}
                width="64px"
                height="64px"
                rounded
              />
            </div>
            <div style={{ fontWeight: 700, fontSize: '0.95rem', marginBottom: '0.25rem' }}>{f.name}</div>
            <div style={{
              fontSize: '0.75rem', color: 'white', background: 'var(--navy)',
              borderRadius: '99px', padding: '2px 10px', display: 'inline-block', marginBottom: '0.5rem',
            }}>{f.role}</div>
            <div style={{ fontSize: '0.75rem', color: 'var(--muted)' }}>{f.stat}</div>
          </div>
        ))}
      </div>
      <PhotoNote>Add friend names, roles, and photos in <code>src/data/azza.js</code> → FRIENDS</PhotoNote>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 5 — NYC LOVE
// ─────────────────────────────────────────────────────────────
function StopNYCLove() {
  return (
    <>
      <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
        <span style={{ fontSize: '4rem' }}>🗽</span>
        <Muted style={{ marginTop: '0.5rem' }}>The moment NYC saw her, it knew.</Muted>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
        {[
          "Memorized every subway line on day one",
          "Has strong opinions about which borough is best",
          "Finds Times Square offensive but will visit for guests",
          "Knows the best hidden spots only locals know",
          "Talks about NYC to people who have never been there",
          "Manhattan energy in her heart, Brooklyn soul",
        ].map(t => (
          <div key={t} style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', fontSize: '0.9rem' }}>
            <span style={{ color: 'var(--spotify-green)', fontWeight: 700 }}>✓</span>
            <span>{t}</span>
          </div>
        ))}
      </div>
      <div style={{ background: '#0A0E2E', color: 'white', borderRadius: '12px', padding: '1rem', textAlign: 'center', marginTop: '1.25rem' }}>
        <div style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>🌆</div>
        <p style={{ fontStyle: 'italic', fontSize: '0.9rem' }}>"The city hasn't seen your final form yet."</p>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 6 — PLAYLIST ARCHIVE
// ─────────────────────────────────────────────────────────────
function StopPlaylists() {
  return (
    <>
      <Muted>An archive of the playlists that defined every era.</Muted>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
        {PLAYLISTS.map((p, i) => (
          <div key={i} style={{
            background: 'white', border: '1.5px solid var(--border)',
            borderRadius: '12px', padding: '1rem',
            display: 'flex', gap: '0.875rem', alignItems: 'flex-start',
            cursor: 'pointer', transition: 'transform 0.2s',
          }}
            onMouseEnter={e => { e.currentTarget.style.transform = 'translateX(4px)'; }}
            onMouseLeave={e => { e.currentTarget.style.transform = ''; }}
          >
            <span style={{ fontSize: '2rem', flexShrink: 0 }}>{p.emoji}</span>
            <div>
              <div style={{ fontWeight: 700, fontSize: '0.95rem' }}>{p.title}</div>
              <div style={{ fontSize: '0.75rem', color: 'var(--muted)', marginBottom: '0.25rem' }}>{p.songs}</div>
              <div style={{ fontSize: '0.85rem', fontStyle: 'italic' }}>{p.note}</div>
            </div>
          </div>
        ))}
      </div>
      <PhotoNote>Edit playlists in <code>src/data/azza.js</code> → PLAYLISTS</PhotoNote>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 7 — THE GAY AGENDA (BINGO)
// ─────────────────────────────────────────────────────────────
const BINGO_SQUARES = [
  "Fell in love with a barista",
  "Made a playlist for a crush",
  '"It\'s just a friend"',
  'Uses "girl..." as punctuation',
  "Has impeccable taste",
  "Cried over a song",
  "Knows everyone's ex lore",
  "Accidentally became the therapist",
  "Owns too many tote bags",
  "Intense opinions about art",
  "Has a complicated situationship",
  "FREE SPACE ✨",
  "Obsessed with a niche artist",
  "Cannot skip a good song",
  "Said 'I'm fine' and wasn't",
  "Made everyone listen to 'this one song'",
  "Has 5+ unfinished journals",
  "Cried at a concert",
  "Late-night existential texting",
  "Quotes movies constantly",
  "Actually very gay",
  "Can't just casually watch a show",
  "Called someone bestie too fast",
  "Complicated feelings about a Gemini",
  "Has a parasocial relationship",
];

function StopGayBingo() {
  const [marked, setMarked] = React.useState(() => {
    const s = new Set();
    s.add(11); // free space
    return s;
  });
  const [won, setWon] = React.useState(false);

  const LINES = [
    [0,1,2,3,4],[5,6,7,8,9],[10,11,12,13,14],[15,16,17,18,19],[20,21,22,23,24],
    [0,5,10,15,20],[1,6,11,16,21],[2,7,12,17,22],[3,8,13,18,23],[4,9,14,19,24],
    [0,6,12,18,24],[4,8,12,16,20],
  ];

  const toggle = (i) => {
    if (i === 11) return;
    const next = new Set(marked);
    if (next.has(i)) next.delete(i); else next.add(i);
    setMarked(next);
    const bingo = LINES.some(line => line.every(j => next.has(j)));
    if (bingo && !won) { setWon(true); fireConfetti(); }
  };

  return (
    <>
      <Muted>Click the squares that apply. You know who you are.</Muted>
      <div role="grid" aria-label="Gay bingo card" style={{
        display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)',
        gap: '5px', maxWidth: '500px', margin: '0 auto 1rem',
      }}>
        {BINGO_SQUARES.map((sq, i) => (
          <div
            key={i}
            role="gridcell"
            aria-pressed={marked.has(i)}
            tabIndex={0}
            onClick={() => toggle(i)}
            onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') toggle(i); }}
            style={{
              background: sq.includes('FREE') ? 'var(--metro-yellow)'
                : marked.has(i) ? 'linear-gradient(135deg, #ff6eb4, #b46eff)'
                : 'white',
              border: `1.5px solid ${marked.has(i) ? 'transparent' : 'var(--border)'}`,
              borderRadius: '8px',
              padding: '0.4rem',
              textAlign: 'center',
              fontSize: '0.65rem',
              fontWeight: 500,
              cursor: i === 11 ? 'default' : 'pointer',
              minHeight: '60px',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              lineHeight: 1.3,
              userSelect: 'none',
              color: marked.has(i) && !sq.includes('FREE') ? 'white' : 'inherit',
              transform: marked.has(i) && i !== 11 ? 'scale(1.04)' : '',
              transition: 'all 0.15s',
            }}
          >
            {sq}
          </div>
        ))}
      </div>
      {won && (
        <div style={{
          background: 'linear-gradient(135deg, #ff6eb4, #b46eff)',
          color: 'white', padding: '1rem 1.25rem',
          borderRadius: '12px', textAlign: 'center',
          animation: 'fadeIn 0.5s ease',
        }}>
          <div style={{ fontWeight: 700, fontSize: '1.1rem' }}>🏆 Achievement Unlocked!</div>
          <div style={{ fontSize: '0.85rem', opacity: 0.9, marginTop: '0.25rem' }}>Actually Very Gay.</div>
        </div>
      )}
      <div style={{ textAlign: 'center', marginTop: '0.75rem' }}>
        <button
          onClick={() => { setMarked(new Set([11])); setWon(false); }}
          style={{ background: 'var(--navy)', color: 'white', border: 'none', padding: '0.5rem 1rem', borderRadius: '12px', cursor: 'pointer', fontSize: '0.8rem', fontFamily: "'Space Grotesk', sans-serif" }}
        >Reset Board</button>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 8 — 3AM THOUGHTS
// ─────────────────────────────────────────────────────────────
function Stop3AM() {
  const thoughts = [
    "What if we just moved to a new city with no plan",
    "Is this song about me or am I projecting",
    "I should learn to code",
    "I could start a podcast",
    "What if I texted them back",
    "I'm going to organize my whole life starting tomorrow",
    "That thing I said in 2016 though",
  ];
  return (
    <div style={{ background: 'var(--navy)', borderRadius: '16px', padding: '1.5rem', color: 'white' }}>
      <div style={{ fontFamily: "'Space Mono', monospace", fontSize: '0.7rem', letterSpacing: '2px', color: 'rgba(255,255,255,0.4)', marginBottom: '0.75rem' }}>3:47 AM</div>
      <div style={{ fontSize: '1.2rem', fontWeight: 700, marginBottom: '1rem' }}>Tonight's Thoughts™</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        {thoughts.map((t, i) => (
          <div key={i} style={{ background: 'rgba(255,255,255,0.07)', borderRadius: '8px', padding: '0.6rem 0.875rem', fontSize: '0.85rem', animation: `fadeIn 0.5s ${i * 0.1}s both` }}>
            🌙 {t}
          </div>
        ))}
      </div>
      <PhotoNote light>Edit in StopModal.jsx → Stop3AM</PhotoNote>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 9 — MERCURY RETROGRADE
// ─────────────────────────────────────────────────────────────
function StopMercury() {
  const traits = [
    { trait: "Air sign energy", desc: "Overthinks everything beautifully", icon: "💨" },
    { trait: "Mutable chaos", desc: "Changes plans, still iconic", icon: "🔄" },
    { trait: "Mercury ruled", desc: "Communication is an art form", icon: "☿" },
    { trait: "June baby", desc: "Summer solstice coded", icon: "☀️" },
    { trait: "Twin duality", desc: "She contains multitudes literally", icon: "♊" },
    { trait: "Charming menace", desc: "Everyone's favourite problem", icon: "😈" },
  ];
  return (
    <>
      <Muted>A Gemini is never just one thing. She contains multitudes.</Muted>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.875rem' }}>
        {traits.map(t => (
          <div key={t.trait} style={{ background: 'white', border: '1.5px solid var(--border)', borderRadius: '12px', padding: '0.875rem' }}>
            <div style={{ fontSize: '1.5rem', marginBottom: '0.25rem' }}>{t.icon}</div>
            <div style={{ fontWeight: 700, fontSize: '0.85rem' }}>{t.trait}</div>
            <div style={{ fontSize: '0.75rem', color: 'var(--muted)', marginTop: '2px' }}>{t.desc}</div>
          </div>
        ))}
      </div>
      <div style={{ background: '#fffde8', borderLeft: '4px solid var(--metro-yellow)', borderRadius: '0 8px 8px 0', padding: '0.875rem 1rem', marginTop: '1rem', fontStyle: 'italic', fontSize: '0.9rem' }}>
        "Mercury retrograde is just Azza's excuse for everything and we allow it."
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 10 — DEEP CUTS
// ─────────────────────────────────────────────────────────────
function StopDeepCuts() {
  return (
    <>
      <Muted>Songs she played you that you still think about.</Muted>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
        {DEEP_CUTS.map((s, i) => (
          <div key={i} style={{ background: 'white', border: '1.5px solid var(--border)', borderRadius: '12px', padding: '1rem', borderLeft: '4px solid var(--spotify-green)' }}>
            <div style={{ fontFamily: "'Space Mono', monospace", fontSize: '0.65rem', color: 'var(--muted)', marginBottom: '0.25rem' }}>TRACK {String(i + 1).padStart(2, '0')}</div>
            <div style={{ fontWeight: 700 }}>{s.title}</div>
            <div style={{ fontSize: '0.8rem', color: 'var(--muted)' }}>{s.artist}</div>
            <div style={{ fontSize: '0.8rem', fontStyle: 'italic', marginTop: '0.4rem' }}>"{s.note}"</div>
          </div>
        ))}
      </div>
      <PhotoNote>Edit songs in <code>src/data/azza.js</code> → DEEP_CUTS</PhotoNote>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 11 — GEMINI COURT
// ─────────────────────────────────────────────────────────────
function StopGeminiCourt() {
  const charges = [
    "Changing the playlist mid-song (repeatedly, deliberately, with no remorse)",
    "Having 17 distinct personalities and using all of them in a single conversation",
    "Overthinking text messages to an unreasonable degree",
    "Winning arguments through vibes alone, without presenting evidence",
    "Being too charming, making it unfair for everyone else",
  ];
  return (
    <div style={{ background: '#f5f5dc', border: '3px solid var(--navy)', borderRadius: '4px', padding: '1.5rem', fontFamily: "'Space Mono', monospace", position: 'relative' }}>
      <div style={{ position: 'absolute', top: '1rem', right: '1rem', border: '3px solid #cc0000', color: '#cc0000', fontSize: '1.3rem', fontWeight: 700, padding: '0.25rem 0.6rem', transform: 'rotate(15deg)', letterSpacing: '2px', opacity: 0.8 }}>
        GUILTY
      </div>
      <div style={{ textAlign: 'center', borderBottom: '2px solid var(--navy)', paddingBottom: '1rem', marginBottom: '1rem' }}>
        <div style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>⚖️</div>
        <div style={{ fontWeight: 700, letterSpacing: '3px' }}>SUPERIOR COURT OF GEMINI SEASON</div>
        <div style={{ fontSize: '0.7rem', color: 'var(--muted)', marginTop: '0.25rem' }}>Criminal Record — Case No. 06142001</div>
        <div style={{ fontSize: '0.7rem', color: 'var(--muted)' }}>Defendant: AZZA (b. June 14, 2001)</div>
      </div>
      <div style={{ fontSize: '0.7rem', letterSpacing: '2px', color: 'var(--muted)', marginBottom: '0.5rem' }}>CHARGES</div>
      {charges.map((c, i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: '0.75rem', padding: '0.5rem 0', borderBottom: '1px dashed rgba(0,0,0,0.2)', fontSize: '0.8rem' }}>
          <span style={{ color: 'var(--muted)', minWidth: '20px' }}>{i + 1}.</span>
          <span>{c}</span>
        </div>
      ))}
      <div style={{ marginTop: '1rem', padding: '0.875rem', background: 'rgba(204,0,0,0.05)', border: '1px solid rgba(204,0,0,0.2)', borderRadius: '8px', textAlign: 'center' }}>
        <div style={{ fontWeight: 700, fontSize: '0.9rem', color: '#cc0000' }}>VERDICT</div>
        <div style={{ fontStyle: 'italic', marginTop: '0.25rem', fontSize: '0.9rem' }}>Guilty (but beloved). Sentenced to being everyone's favourite person forever.</div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 12 — SPRING ENERGY
// ─────────────────────────────────────────────────────────────
function StopSpringEnergy() {
  const tags = ["warm","chaotic","funny","charming","overthinking but thriving","main character","always right","vibe architect","impossibly cool"];
  return (
    <>
      <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
        <span style={{ fontSize: '4rem' }}>🌸</span>
        <div style={{ fontFamily: "'Abril Fatface', serif", fontSize: '1.8rem', marginTop: '0.5rem' }}>June 14th Girl</div>
        <Muted style={{ marginTop: '0.5rem' }}>A Gemini born at peak summer energy. This explains everything.</Muted>
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', justifyContent: 'center', marginBottom: '1.25rem' }}>
        {tags.map(t => (
          <span key={t} style={{ display: 'inline-flex', alignItems: 'center', background: 'var(--soft-pink)', color: '#8b1a5e', fontSize: '0.75rem', fontWeight: 600, padding: '0.2rem 0.7rem', borderRadius: '99px' }}>{t}</span>
        ))}
      </div>
      <div style={{ background: 'linear-gradient(135deg,#fff0f8,#f0f4ff)', borderRadius: '12px', padding: '1.25rem', textAlign: 'center' }}>
        <p style={{ fontStyle: 'italic', fontSize: '0.95rem', lineHeight: 1.7 }}>
          June babies are the ones who show up late, make everyone laugh, then leave and take all the good energy with them. Azza has never once disproven this theory.
        </p>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 13 — NYC SIMULATOR (mini-game)
// ─────────────────────────────────────────────────────────────
function StopNYCSim() {
  const [playerX, setPlayerX] = React.useState(60);
  const [score, setScore] = React.useState(0);
  const [collected, setCollected] = React.useState(new Set());
  const [won, setWon] = React.useState(false);
  const canvasRef = React.useRef(null);

  const COLLECTIBLES = [
    { id: 'coffee1', x: 22, y: 80, label: '☕', type: 'coffee', pts: 10 },
    { id: 'coffee2', x: 52, y: 80, label: '☕', type: 'coffee', pts: 10 },
    { id: 'coffee3', x: 78, y: 80, label: '☕', type: 'coffee', pts: 10 },
    { id: 'cat',     x: 68, y: 64, label: '🐱', type: 'cat',    pts: 20 },
    { id: 'subway',  x: 88, y: 64, label: '🚇', type: 'subway', pts: 30 },
  ];
  const OBSTACLES = [
    { id: 't1', x: 35, label: '👔' },
    { id: 't2', x: 60, label: '📸' },
  ];

  const coffees = collected.size > 0 ? [...collected].filter(id => id.startsWith('coffee')).length : 0;
  const hasCat = collected.has('cat');
  const hasSubway = collected.has('subway');

  const movePlayer = React.useCallback((dir) => {
    if (won) return;
    setPlayerX(prev => {
      const next = dir === 'left' ? Math.max(10, prev - 24) : Math.min(360, prev + 24);
      // Check collectibles
      COLLECTIBLES.forEach(c => {
        if (collected.has(c.id)) return;
        const cx = (c.x / 100) * 400;
        if (Math.abs(next - cx) < 35) {
          setCollected(prev => new Set([...prev, c.id]));
          setScore(s => s + c.pts);
          if (c.type === 'cat') showToast('pspspspsps 🐱');
        }
      });
      return next;
    });
  }, [won, collected]);

  useEffect(() => {
    const handler = (e) => {
      if (e.key === 'ArrowLeft') { e.preventDefault(); movePlayer('left'); }
      if (e.key === 'ArrowRight') { e.preventDefault(); movePlayer('right'); }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [movePlayer]);

  useEffect(() => {
    if (coffees >= 3 && hasCat && hasSubway && !won) {
      setWon(true);
      fireConfetti();
    }
  }, [coffees, hasCat, hasSubway, won]);

  return (
    <>
      <Muted>Collect ☕×3, pet 🐱, catch 🚇. Avoid 👔 tourists. Arrow keys or buttons below.</Muted>
      {/* HUD */}
      <div style={{ display: 'flex', gap: '1rem', justifyContent: 'space-between', padding: '0.75rem 1rem', background: 'var(--navy)', color: 'white', fontFamily: "'Space Mono', monospace", fontSize: '0.8rem', flexWrap: 'wrap', borderRadius: '8px 8px 0 0' }}>
        <span>Score: <strong style={{ color: 'var(--metro-yellow)' }}>{score}</strong></span>
        <span>☕ {coffees}/3</span>
        <span>🐱 {hasCat ? 1 : 0}/1</span>
        <span>🚇 {hasSubway ? 1 : 0}/1</span>
      </div>
      {/* Canvas */}
      <div ref={canvasRef} style={{ background: '#87CEEB', position: 'relative', height: '260px', border: '2px solid var(--border)', borderTop: 'none', overflow: 'hidden', borderRadius: '0 0 8px 8px' }}>
        {/* Buildings */}
        {[{l:'5%',w:60,h:120},{l:'20%',w:80,h:160},{l:'40%',w:50,h:100},{l:'58%',w:90,h:140},{l:'80%',w:70,h:160}].map((b,i) => (
          <div key={i} style={{ position: 'absolute', bottom: '60px', left: b.l, width: b.w, height: b.h, background: 'var(--navy)', borderRadius: '2px 2px 0 0' }} />
        ))}
        {/* Ground */}
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: '60px', background: '#555' }} />
        {/* Player */}
        <div style={{ position: 'absolute', fontSize: '1.8rem', bottom: '64px', left: playerX, transition: 'left 0.05s', zIndex: 10 }} aria-label="Player character">🧍‍♀️</div>
        {/* Collectibles */}
        {COLLECTIBLES.map(c => !collected.has(c.id) && (
          <div key={c.id} style={{ position: 'absolute', fontSize: '1.4rem', left: `${c.x}%`, bottom: c.y, animation: 'bounce 1s infinite', zIndex: 5 }}>{c.label}</div>
        ))}
        {/* Obstacles */}
        {OBSTACLES.map(o => (
          <div key={o.id} style={{ position: 'absolute', fontSize: '1.4rem', left: `${o.x}%`, bottom: '64px', zIndex: 5 }}>{o.label}</div>
        ))}
        {/* Win overlay */}
        {won && (
          <div style={{ position: 'absolute', inset: 0, background: 'rgba(10,14,46,0.9)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '0.75rem', zIndex: 20 }}>
            <div style={{ fontSize: '2rem' }}>🎉</div>
            <div style={{ color: 'white', fontWeight: 700, textAlign: 'center', padding: '0 1rem' }}>You have been accepted as an honorary Brooklyn lesbian.</div>
          </div>
        )}
      </div>
      {/* Controls */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 44px)', gridTemplateRows: 'repeat(2, 44px)', gap: '4px', margin: '1rem auto 0', width: 'fit-content' }}>
        <div style={{ gridColumn: 2 }}><CtrlBtn onClick={() => {}}>↑</CtrlBtn></div>
        <CtrlBtn onClick={() => movePlayer('left')}>←</CtrlBtn>
        <CtrlBtn onClick={() => {}}>↓</CtrlBtn>
        <CtrlBtn onClick={() => movePlayer('right')}>→</CtrlBtn>
      </div>
      <div style={{ textAlign: 'center', marginTop: '0.75rem' }}>
        <button onClick={() => { setPlayerX(60); setScore(0); setCollected(new Set()); setWon(false); }} style={{ background: 'var(--navy)', color: 'white', border: 'none', padding: '0.5rem 1rem', borderRadius: '12px', cursor: 'pointer', fontFamily: "'Space Grotesk', sans-serif", fontSize: '0.8rem' }}>🔄 Reset</button>
      </div>
    </>
  );
}

function CtrlBtn({ onClick, children }) {
  return (
    <button onClick={onClick} style={{ background: 'var(--navy)', color: 'white', border: 'none', borderRadius: '8px', fontSize: '1rem', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', width: '44px', height: '44px', fontFamily: "'Space Grotesk', sans-serif" }}>
      {children}
    </button>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 14 — CONCERTS
// ─────────────────────────────────────────────────────────────
function StopConcerts() {
  return (
    <>
      <Muted>Every concert left a mark. These are the ones that changed things.</Muted>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
        {CONCERTS.map((c, i) => (
          <div key={i} style={{ background: 'white', border: '1.5px solid var(--border)', borderRadius: '12px', overflow: 'hidden' }}>
            {c.photo && (
              <PhotoOrEmoji src={c.photo} emoji="🎤" alt={c.show} height="120px" style={{ borderRadius: 0 }} />
            )}
            <div style={{ padding: '1rem', display: 'flex', gap: '0.875rem' }}>
              <div style={{ background: 'var(--navy)', color: 'white', borderRadius: '8px', padding: '0.5rem', textAlign: 'center', minWidth: '48px', height: 'fit-content' }}>
                <div style={{ fontSize: '0.65rem', fontFamily: "'Space Mono', monospace" }}>{c.year}</div>
                <div style={{ fontSize: '1.2rem' }}>🎤</div>
              </div>
              <div>
                <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>{c.show}</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--muted)' }}>{c.venue}</div>
                <div style={{ fontSize: '0.8rem', fontStyle: 'italic', marginTop: '0.25rem' }}>{c.note}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
      <PhotoNote>Add concert photos in <code>public/images/concerts/</code> and set in <code>src/data/azza.js</code></PhotoNote>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 15 — HOT TAKES
// ─────────────────────────────────────────────────────────────
function StopHotTakes() {
  return (
    <>
      <Muted>The opinions. The takes. The stances she will die on.</Muted>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
        {HOT_TAKES.map((t, i) => (
          <div key={i} style={{ background: 'white', border: '1.5px solid var(--border)', borderRadius: '12px', padding: '0.875rem 1rem', display: 'flex', alignItems: 'center', gap: '0.875rem' }}>
            <span style={{ fontSize: '1rem' }}>{t.heat}</span>
            <span style={{ fontSize: '0.9rem' }}>{t.take}</span>
          </div>
        ))}
      </div>
      <div style={{ background: '#fff3cd', borderRadius: '12px', padding: '0.875rem', marginTop: '1rem', fontSize: '0.85rem' }}>
        🔥 <strong>Disclaimer:</strong> These takes are correct and she will not be taking questions.
      </div>
      <PhotoNote>Edit takes in <code>src/data/azza.js</code> → HOT_TAKES</PhotoNote>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 16 — NIGHT SKY
// ─────────────────────────────────────────────────────────────
function StopNightSky() {
  const stars = React.useMemo(() => Array.from({ length: 30 }, (_, i) => ({
    id: i, l: Math.random() * 100, t: Math.random() * 100,
    s: 1 + Math.random() * 3, dur: 2 + Math.random() * 3, delay: Math.random() * 2,
  })), []);
  return (
    <div style={{ background: 'var(--navy)', borderRadius: '16px', padding: '2rem', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, opacity: 0.4, pointerEvents: 'none' }}>
        {stars.map(s => (
          <div key={s.id} style={{ position: 'absolute', left: `${s.l}%`, top: `${s.t}%`, width: s.s, height: s.s, background: 'white', borderRadius: '50%', animation: `starFloat ${s.dur}s ${s.delay}s infinite` }} />
        ))}
      </div>
      <div style={{ position: 'relative', zIndex: 1 }}>
        <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🌙</div>
        <div style={{ fontFamily: "'Abril Fatface', serif", fontSize: '1.5rem', color: 'var(--metro-yellow)', marginBottom: '0.75rem' }}>Late Night Hours</div>
        <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: '0.9rem', lineHeight: 1.7, maxWidth: '340px', margin: '0 auto' }}>
          The version of Azza that exists between midnight and 4am is different. More honest. More herself. She saves her realest thoughts for the night sky.
        </p>
        <div style={{ marginTop: '1.5rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          {["♊ Gemini rising","🌙 Moon hours","✨ No context needed","🎵 The playlist is on"].map(s => (
            <div key={s} style={{ color: 'rgba(255,255,255,0.6)', fontSize: '0.85rem' }}>{s}</div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 17 — MONGOLIAN PRIDE
// ─────────────────────────────────────────────────────────────
const MONGOLIA_ITEMS = [
  { emoji: "🐎", name: "The Horse",  reveal: "The spirit of the steppe runs in you. Wild, free, and unstoppable." },
  { emoji: "🦅", name: "The Eagle",  reveal: "You have the eye of the eagle — you see what others miss." },
  { emoji: "🏕️", name: "The Ger",    reveal: "Home is wherever you carry your heart. Mongolia lives in yours." },
  { emoji: "🌄", name: "The Steppe", reveal: "Vast. Beautiful. Quietly powerful." },
  { emoji: "⭐", name: "The Stars",  reveal: "Under the same sky, no matter how far you roam." },
  { emoji: "🎶", name: "The Music",  reveal: "Mongolian music is some of the most beautiful on earth. Like you." },
];

function StopMongolia() {
  const [active, setActive] = React.useState(null);
  return (
    <>
      <Muted>Click each element to reveal its message.</Muted>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1rem', marginBottom: '1rem' }}>
        {MONGOLIA_ITEMS.map((item, i) => (
          <div key={i}
            onClick={() => setActive(i)}
            role="button" tabIndex={0}
            onKeyDown={e => e.key === 'Enter' && setActive(i)}
            aria-label={item.name}
            style={{
              background: active === i ? '#FFF8DC' : 'white',
              border: `1.5px solid ${active === i ? '#B8860B' : 'var(--border)'}`,
              borderRadius: '16px', padding: '1.25rem', textAlign: 'center',
              cursor: 'pointer', transition: 'all 0.3s',
              transform: active === i ? 'scale(1.05)' : '',
            }}
          >
            <div style={{ fontSize: '3rem', marginBottom: '0.5rem' }}>{item.emoji}</div>
            <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>{item.name}</div>
          </div>
        ))}
      </div>
      {active !== null && (
        <div style={{ background: 'linear-gradient(135deg,#FFF8DC,#FFF5E4)', border: '2px solid #B8860B', borderRadius: '12px', padding: '1.25rem', textAlign: 'center', animation: 'fadeIn 0.4s ease' }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>{MONGOLIA_ITEMS[active].emoji}</div>
          <div style={{ fontStyle: 'italic', fontSize: '0.95rem', lineHeight: 1.7 }}>{MONGOLIA_ITEMS[active].reveal}</div>
        </div>
      )}
      <div style={{ background: 'linear-gradient(135deg,#0A0E2E,#1a2a5e)', borderRadius: '12px', padding: '1.25rem', marginTop: '1rem', textAlign: 'center' }}>
        <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: '0.9rem', lineHeight: 1.7, fontStyle: 'italic' }}>
          "No matter where life takes you, your roots make you extraordinary."
        </p>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 18 — BODEGA CAT
// ─────────────────────────────────────────────────────────────
function StopBodegaCat() {
  const [clicks, setClicks] = React.useState(0);
  const unlocked = clicks >= 5;
  return (
    <>
      <div style={{ textAlign: 'center', padding: '1rem' }}>
        <Muted style={{ marginBottom: '1.5rem' }}>A sacred NYC institution. Click the cat. Trust.</Muted>
        <div
          onClick={() => { setClicks(c => c + 1); if (clicks + 1 >= 5) showToast('pspspspsps 🐱'); }}
          role="button" tabIndex={0}
          onKeyDown={e => e.key === 'Enter' && setClicks(c => c + 1)}
          aria-label="Bodega cat, click to interact"
          style={{ fontSize: '6rem', cursor: 'pointer', display: 'inline-block', animation: 'bounce 2s infinite', transition: 'transform 0.15s', userSelect: 'none' }}
        >🐱</div>
        <div style={{ fontFamily: "'Space Mono', monospace", fontSize: '0.8rem', color: 'var(--muted)', marginTop: '0.75rem' }}>
          {unlocked ? 'Achievement unlocked 🐾' : `${clicks} click${clicks !== 1 ? 's' : ''} — keep going...`}
        </div>
        {unlocked && (
          <div style={{ background: 'var(--navy)', color: 'var(--metro-yellow)', padding: '0.875rem 1.5rem', borderRadius: '12px', fontFamily: "'Abril Fatface', serif", fontSize: '1.5rem', marginTop: '1rem', animation: 'fadeIn 0.4s' }}>
            pspspspsps 🐾
          </div>
        )}
      </div>
      <div style={{ background: 'white', border: '1.5px solid var(--border)', borderRadius: '12px', padding: '1rem', marginTop: '1rem' }}>
        <div style={{ fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.25rem' }}>About this cat</div>
        <div style={{ fontSize: '0.8rem', color: 'var(--muted)' }}>Name: Unknown. Lives at the bodega on the corner. Has been there since before anyone can remember. Accepts: head scratches, treats. Rejects: Monday mornings, loud tourists.</div>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 19 — ALBUMS
// ─────────────────────────────────────────────────────────────
function StopAlbums() {
  return (
    <>
      <Muted>The records that became part of her identity.</Muted>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
        {ALBUMS.map((a, i) => (
          <div key={i} style={{ background: 'white', border: '1.5px solid var(--border)', borderRadius: '12px', overflow: 'hidden', cursor: 'pointer', transition: 'transform 0.2s' }}
            onMouseEnter={e => { e.currentTarget.style.transform = 'scale(1.03)'; }}
            onMouseLeave={e => { e.currentTarget.style.transform = ''; }}
          >
            <PhotoOrEmoji src={a.photo} emoji={a.emoji} alt={a.title} height="80px" style={{ borderRadius: 0, background: 'var(--navy)' }} />
            <div style={{ padding: '0.75rem' }}>
              <div style={{ fontWeight: 700, fontSize: '0.85rem' }}>{a.title}</div>
              <div style={{ fontSize: '0.75rem', color: 'var(--muted)' }}>{a.artist} · {a.year}</div>
              <div style={{ fontSize: '0.75rem', fontStyle: 'italic', marginTop: '0.25rem' }}>{a.note}</div>
            </div>
          </div>
        ))}
      </div>
      <PhotoNote>Add album art in <code>public/images/albums/</code> and set in <code>src/data/azza.js</code></PhotoNote>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 20 — WIKI (AZZA LORE)
// ─────────────────────────────────────────────────────────────
function StopWiki() {
  return (
    <div style={{ border: '1px solid #a2a9b1', borderRadius: '4px', overflow: 'hidden', fontSize: '0.9rem' }}>
      <div style={{ background: '#f8f9fa', borderBottom: '1px solid #a2a9b1', padding: '0.75rem 1rem', fontSize: '0.8rem', color: '#555', fontFamily: "'Space Mono', monospace" }}>
        📄 Azza — Wikipedia, The Free Encyclopedia
      </div>
      <div style={{ padding: '1rem 1.25rem' }}>
        {/* Infobox */}
        <div style={{ float: 'right', margin: '0 0 1rem 1.5rem', background: '#f8f9fa', border: '1px solid #a2a9b1', padding: '0.75rem', borderRadius: '4px', width: '190px', fontSize: '0.8rem' }}>
          <div style={{ textAlign: 'center', fontWeight: 700, marginBottom: '0.5rem' }}>Azza</div>
          <div style={{ textAlign: 'center', fontSize: '2rem', marginBottom: '0.5rem' }}>🌟</div>
          {[['Born','June 14, 2001'],['Origin','Mongolia'],['Occupation','Professional Music Nerd'],['Sign','♊ Gemini'],['Known for','Immaculate taste']].map(([k,v]) => (
            <div key={k} style={{ display: 'flex', gap: '0.5rem', padding: '0.2rem 0', borderTop: '1px solid #eee', fontSize: '0.75rem' }}>
              <span style={{ color: 'var(--muted)', minWidth: '70px' }}>{k}</span>
              <span>{v}</span>
            </div>
          ))}
        </div>
        <div style={{ fontFamily: "'Abril Fatface', serif", fontSize: '1.8rem', borderBottom: '1px solid #a2a9b1', paddingBottom: '0.5rem', marginBottom: '1rem' }}>
          Azza <span style={{ fontWeight: 400, fontSize: '1rem', fontFamily: "'Space Grotesk', sans-serif" }}>(2001–present)</span>
        </div>
        <p style={{ marginBottom: '0.75rem', lineHeight: 1.7 }}>
          <strong>Azza</strong> is a Mongolian-born cultural phenomenon, widely recognized for her exceptional taste in music,<sup style={{ color: '#0645ad', fontSize: '0.65rem' }}>[1]</sup> unwavering commitment to bangs,<sup style={{ color: '#0645ad', fontSize: '0.65rem' }}>[2]</sup> and her role as the de facto emotional center of every friend group she has ever joined.<sup style={{ color: '#0645ad', fontSize: '0.65rem' }}>[3]</sup>
        </p>
        <p style={{ marginBottom: '0.75rem', lineHeight: 1.7 }}>
          Born on June 14, 2001 under the sign of Gemini, Azza demonstrated from an early age what scholars have described as "an almost supernatural ability to identify a banger."<sup style={{ color: '#0645ad', fontSize: '0.65rem' }}>[4]</sup>
        </p>
        <div style={{ fontWeight: 700, borderBottom: '1px solid #a2a9b1', margin: '1rem 0 0.5rem', paddingBottom: '0.25rem' }}>Known for</div>
        <ul style={{ paddingLeft: '1.25rem', lineHeight: 2 }}>
          <li>Immaculate playlists (peer-reviewed)</li>
          <li>Impeccable taste across all categories</li>
          <li>Being funny against all odds<sup style={{ color: '#0645ad', fontSize: '0.65rem' }}>[8]</sup></li>
          <li>Making people feel genuinely loved</li>
          <li>NYC obsession (clinical diagnosis pending)</li>
          <li>Having bangs before it was cool</li>
        </ul>
        <div style={{ marginTop: '1rem', paddingTop: '1rem', borderTop: '1px solid #eee', fontSize: '0.7rem', color: 'var(--muted)', fontFamily: "'Space Mono', monospace" }}>
          [1] Everyone who has ever met her. [2] The mirror. [3] Documented friend group records. [4] Unnamed sources. [8] Observed empirically.
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 21 — QUARTER CENTURY
// ─────────────────────────────────────────────────────────────
function StopQuarterCentury() {
  return (
    <>
      <div style={{ textAlign: 'center', padding: '1rem 0' }}>
        <div style={{ fontFamily: "'Abril Fatface', serif", fontSize: '5rem', color: 'var(--navy)', lineHeight: 1 }}>25</div>
        <div style={{ fontSize: '0.9rem', color: 'var(--muted)', fontFamily: "'Space Mono', monospace", letterSpacing: '2px' }}>YEARS OF AZZA</div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '0.75rem', margin: '1rem 0' }}>
        {[{ stat: '∞', label: 'Songs heard' }, { stat: '25', label: 'Years of greatness' }, { stat: '1', label: 'Person like this' }].map(s => (
          <div key={s.label} style={{ background: 'var(--navy)', color: 'white', borderRadius: '12px', padding: '1rem', textAlign: 'center' }}>
            <div style={{ fontFamily: "'Abril Fatface', serif", fontSize: '1.8rem', color: 'var(--metro-yellow)' }}>{s.stat}</div>
            <div style={{ fontSize: '0.7rem', opacity: 0.6, marginTop: '0.25rem' }}>{s.label}</div>
          </div>
        ))}
      </div>
      <div style={{ background: 'linear-gradient(135deg,#fff0f8,#f0f4ff)', borderRadius: '12px', padding: '1.25rem', textAlign: 'center' }}>
        <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>🎂</div>
        <p style={{ fontStyle: 'italic', fontSize: '0.95rem', lineHeight: 1.7 }}>
          25 is just the beginning. You're exactly who you're supposed to be — and somehow you're only getting more yourself.
        </p>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 22 — LOVE LETTERS
// ─────────────────────────────────────────────────────────────
function StopLoveLetters() {
  return (
    <>
      <Muted>Letters from people and things that love you.</Muted>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
        {LOVE_LETTERS.map((l, i) => (
          <div key={i} style={{ background: 'white', border: '1.5px solid var(--border)', borderRadius: '12px', padding: '1.1rem', animation: `slideUp 0.4s ${i * 0.1}s both` }}>
            <div style={{ fontFamily: "'Space Mono', monospace", fontSize: '0.65rem', color: 'var(--muted)', marginBottom: '0.4rem', letterSpacing: '1px' }}>
              FROM: {l.from.toUpperCase()}
            </div>
            <div style={{ fontSize: '0.9rem', lineHeight: 1.65, fontStyle: 'italic' }}>{l.msg}</div>
          </div>
        ))}
      </div>
      <PhotoNote>Add real friend messages in <code>src/data/azza.js</code> → LOVE_LETTERS</PhotoNote>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
//  STOP 25 — FINALE
// ─────────────────────────────────────────────────────────────
function StopFinale() {
  const stars = React.useMemo(() => Array.from({ length: 50 }, (_, i) => ({
    id: i, l: Math.random() * 100, t: Math.random() * 100,
    s: 1 + Math.random() * 3, dur: 2 + Math.random() * 4, delay: Math.random() * 3,
  })), []);

  React.useEffect(() => { fireConfetti(); }, []);

  return (
    <div style={{ background: 'var(--navy)', minHeight: '500px', borderRadius: '16px', position: 'relative', overflow: 'hidden', padding: '2rem', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', gap: '1.5rem' }}>
      {/* Stars */}
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        {stars.map(s => (
          <div key={s.id} style={{ position: 'absolute', background: 'white', borderRadius: '50%', width: s.s, height: s.s, left: `${s.l}%`, top: `${s.t}%`, animation: `starFloat ${s.dur}s ${s.delay}s infinite` }} />
        ))}
      </div>
      {/* Gemini constellation */}
      <svg style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', width: '200px', height: '200px', opacity: 0.3 }} viewBox="0 0 200 200" aria-hidden="true">
        <circle cx="100" cy="30" r="4" fill="white" opacity="0.8"/>
        <circle cx="60" cy="80" r="3" fill="white" opacity="0.7"/>
        <circle cx="140" cy="80" r="3" fill="white" opacity="0.7"/>
        <circle cx="75" cy="140" r="3" fill="white" opacity="0.6"/>
        <circle cx="125" cy="140" r="3" fill="white" opacity="0.6"/>
        <path d="M100 30 L60 80 L140 80 L100 30 M60 80 L75 140 M140 80 L125 140" stroke="white" strokeWidth="1" fill="none" strokeDasharray="500" style={{ animation: 'constellationDraw 3s ease forwards' }}/>
        <text x="110" y="25" fill="white" fontSize="10" fontFamily="Space Grotesk">♊</text>
      </svg>
      {/* Friend messages */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', maxWidth: '420px', position: 'relative', zIndex: 1 }}>
        {FINALE_MESSAGES.map((m, i) => (
          <div key={i} style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)', borderRadius: '12px', padding: '0.75rem 1rem', color: 'rgba(255,255,255,0.9)', fontSize: '0.9rem', lineHeight: 1.5, animation: `fadeIn 0.8s ${0.5 + i * 0.5}s both`, textAlign: 'left' }}>
            <strong style={{ color: 'var(--metro-yellow)' }}>{m.from}:</strong> "{m.msg}"
          </div>
        ))}
      </div>
      <div style={{ color: 'rgba(255,255,255,0.8)', fontSize: '1rem', lineHeight: 1.7, maxWidth: '400px', animation: 'fadeIn 1s 2.5s both', position: 'relative', zIndex: 1 }}>
        Thank you for making the people around you laugh louder, dance harder, and love more openly.
      </div>
      <div style={{ fontFamily: "'Abril Fatface', serif", color: 'var(--metro-yellow)', fontSize: 'clamp(1.5rem, 6vw, 2.5rem)', animation: 'fadeIn 1s 3s both', position: 'relative', zIndex: 1 }}>
        Happy 25th Birthday, Azza. 🎂
      </div>
      <div style={{ color: 'rgba(255,255,255,0.6)', fontStyle: 'italic', fontSize: '0.95rem', animation: 'fadeIn 1s 3.5s both', position: 'relative', zIndex: 1 }}>
        The city hasn't seen your final form yet.
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  FILLER STOP
// ─────────────────────────────────────────────────────────────
function StopFiller({ emoji, title, desc }) {
  return (
    <div style={{ textAlign: 'center', padding: '2rem 1rem' }}>
      <span style={{ fontSize: '4rem', display: 'block', marginBottom: '1rem' }}>{emoji}</span>
      <div style={{ fontFamily: "'Abril Fatface', serif", fontSize: '1.5rem', marginBottom: '0.5rem' }}>{title}</div>
      <p style={{ color: 'var(--muted)', fontSize: '0.9rem' }}>{desc}</p>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  SHARED SMALL COMPONENTS
// ─────────────────────────────────────────────────────────────
function Muted({ children, style }) {
  return <p style={{ color: 'var(--muted)', fontSize: '0.9rem', marginBottom: '1.25rem', ...style }}>{children}</p>;
}

function Divider({ children }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', margin: '1.5rem 0', color: 'var(--muted)', fontSize: '0.8rem', fontFamily: "'Space Mono', monospace" }}>
      <div style={{ flex: 1, height: '1px', background: 'var(--border)' }} />
      {children}
      <div style={{ flex: 1, height: '1px', background: 'var(--border)' }} />
    </div>
  );
}

function PhotoNote({ children, light }) {
  return (
    <p style={{ fontSize: '0.78rem', color: light ? 'rgba(255,255,255,0.4)' : 'var(--muted)', marginTop: '1rem', textAlign: 'center', fontStyle: 'italic' }}>
      💡 {children}
    </p>
  );
}
