import React, { useEffect, useCallback } from 'react';

// ── CONFETTI ─────────────────────────────────────────────────
// Injects confetti pieces into #confetti-root (in App.jsx)
export function fireConfetti(rainbow = false) {
  const pieces = rainbow
    ? ['🌈', '🏳️‍🌈', '💜', '💛', '💚', '💙', '🌸', '✨']
    : ['🌸', '✨', '🎉', '💕', '⭐', '🌈', '💜', '🌟', '🎊', '🏳️‍🌈'];

  const container = document.getElementById('confetti-root');
  if (!container) return;

  const count = rainbow ? 60 : 30;
  for (let i = 0; i < count; i++) {
    setTimeout(() => {
      const el = document.createElement('div');
      el.style.cssText = `
        position: fixed;
        pointer-events: none;
        z-index: 9999;
        left: ${Math.random() * 100}vw;
        top: -30px;
        font-size: ${0.8 + Math.random() * (rainbow ? 1.2 : 1)}rem;
        animation: confettiFall ${2 + Math.random() * (rainbow ? 3 : 2)}s ease forwards;
        animation-delay: ${Math.random() * 0.5}s;
      `;
      el.textContent = pieces[Math.floor(Math.random() * pieces.length)];
      container.appendChild(el);
      setTimeout(() => el.remove(), 5000);
    }, i * (rainbow ? 40 : 60));
  }
}

// ── TOAST ────────────────────────────────────────────────────
// Simple toast notification using a shared DOM node.
export function showToast(msg, duration = 3000) {
  const toast = document.getElementById('toast-root');
  if (!toast) return;
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.remove('show'), duration);
}

// ── TOAST COMPONENT ──────────────────────────────────────────
export function ToastContainer() {
  return (
    <div
      id="toast-root"
      style={{
        position: 'fixed',
        top: '1.5rem',
        left: '50%',
        transform: 'translateX(-50%) translateY(-100px)',
        background: 'var(--navy)',
        color: 'white',
        padding: '0.75rem 1.5rem',
        borderRadius: '99px',
        fontWeight: 600,
        fontSize: '0.95rem',
        zIndex: 9998,
        transition: 'transform 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
        border: '2px solid var(--metro-yellow)',
        whiteSpace: 'nowrap',
        maxWidth: '90vw',
        textAlign: 'center',
        pointerEvents: 'none',
      }}
      style-show-override
    />
  );
}

// CSS for the toast .show state — injected once
if (typeof document !== 'undefined' && !document.getElementById('toast-style')) {
  const s = document.createElement('style');
  s.id = 'toast-style';
  s.textContent = `#toast-root.show { transform: translateX(-50%) translateY(0) !important; }`;
  document.head.appendChild(s);
}
