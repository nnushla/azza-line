import React from 'react';

/**
 * PhotoOrEmoji
 * Shows a real photo if `src` is provided and loads successfully,
 * otherwise renders an emoji placeholder.
 *
 * Props:
 *   src      — image path e.g. "/images/friends/friend-1.jpg" or null
 *   emoji    — fallback emoji string e.g. "🌟"
 *   alt      — alt text for the image
 *   width    — CSS width (default "100%")
 *   height   — CSS height (default "180px")
 *   style    — additional inline styles
 *   rounded  — if true, applies border-radius: 50% (circle)
 */
export default function PhotoOrEmoji({
  src,
  emoji = '📸',
  alt = '',
  width = '100%',
  height = '180px',
  style = {},
  rounded = false,
}) {
  const [failed, setFailed] = React.useState(false);

  const baseStyle = {
    width,
    height,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: rounded ? '50%' : '12px',
    overflow: 'hidden',
    flexShrink: 0,
    ...style,
  };

  if (src && !failed) {
    return (
      <div style={baseStyle}>
        <img
          src={src}
          alt={alt}
          onError={() => setFailed(true)}
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            display: 'block',
          }}
        />
      </div>
    );
  }

  return (
    <div
      style={{
        ...baseStyle,
        background: 'linear-gradient(135deg, #f0e8ff, #ffe8f0)',
        border: '2px dashed rgba(10,14,46,0.15)',
        flexDirection: 'column',
        gap: '0.25rem',
      }}
      title={src ? `Image not found: ${src}` : 'No photo set — add one in src/data/azza.js'}
    >
      <span style={{ fontSize: rounded ? '2rem' : '2.5rem', opacity: 0.7 }}>{emoji}</span>
      {!rounded && (
        <span style={{ fontSize: '0.65rem', color: '#6b6b8a', textAlign: 'center', padding: '0 0.5rem' }}>
          {src ? '⚠️ photo not found' : '📸 add photo in azza.js'}
        </span>
      )}
    </div>
  );
}
