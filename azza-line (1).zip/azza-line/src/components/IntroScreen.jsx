import React from 'react';

export default function IntroScreen({ onStart }) {
  const handleStart = () => {
    // Play a quick subway-arrival sound via Web Audio API
    try {
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.setValueAtTime(200, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(400, ctx.currentTime + 0.1);
      osc.frequency.exponentialRampToValueAtTime(150, ctx.currentTime + 0.4);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.6);
      osc.start();
      osc.stop(ctx.currentTime + 0.6);
    } catch (e) {
      // Audio not available — no problem
    }
    onStart();
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'var(--navy)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Star background */}
      <StarsBg />

      {/* Main content */}
      <div style={{
        position: 'relative',
        zIndex: 2,
        textAlign: 'center',
        padding: '2rem',
        animation: 'fadeIn 1s ease both',
      }}>
        <div style={{
          background: 'var(--metro-yellow)',
          color: 'var(--navy)',
          fontFamily: "'Space Mono', monospace",
          fontWeight: 700,
          padding: '0.5rem 1.5rem',
          borderRadius: '4px',
          fontSize: '0.75rem',
          letterSpacing: '3px',
          textTransform: 'uppercase',
          display: 'inline-block',
          marginBottom: '1.5rem',
          animation: 'pulse 2s infinite',
        }}>
          🚇 MTA New York City Transit
        </div>

        <div style={{
          fontFamily: "'Abril Fatface', serif",
          fontSize: 'clamp(3rem, 12vw, 7rem)',
          color: 'white',
          lineHeight: 1,
          marginBottom: '0.5rem',
          animation: 'trainSlide 1s ease 0.3s both',
        }}>
          The <span style={{ color: 'var(--metro-yellow)' }}>A-ZZA</span>
          <br />Line
        </div>

        <div style={{
          color: 'rgba(255,255,255,0.7)',
          fontSize: 'clamp(0.9rem, 3vw, 1.1rem)',
          letterSpacing: '2px',
          fontFamily: "'Space Mono', monospace",
          marginBottom: '2rem',
          animation: 'fadeIn 1s 0.6s both',
        }}>
          NEXT STOP: AZZA, AGE 25
        </div>

        {/* Passenger card */}
        <div style={{
          background: 'rgba(255,255,255,0.08)',
          border: '1px solid rgba(255,255,255,0.15)',
          borderRadius: '16px',
          padding: '1.25rem 2rem',
          maxWidth: '360px',
          margin: '0 auto 2rem',
          textAlign: 'left',
          animation: 'fadeIn 1s 0.9s both',
        }}>
          <div style={{
            color: 'var(--metro-yellow)',
            fontFamily: "'Space Mono', monospace",
            fontSize: '0.65rem',
            letterSpacing: '3px',
            textTransform: 'uppercase',
            marginBottom: '0.75rem',
          }}>
            Passenger Details
          </div>
          <ul style={{ listStyle: 'none' }}>
            {[
              '🇲🇳 Mongolian (and proud)',
              '🎵 Certified Music Nerd',
              '♊ Gemini Menace (June 14)',
              '✂️ Certified Bangs™',
              '🏙️ NYC Enthusiast',
              '🤎 Brown Friend Collector',
              '🏳️‍🌈 Hella Gay',
            ].map((item) => (
              <li key={item} style={{
                color: 'rgba(255,255,255,0.9)',
                fontSize: '0.95rem',
                padding: '0.2rem 0',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
              }}>
                <span style={{ color: 'var(--spotify-green)', fontWeight: 700 }}>✓</span>
                {item}
              </li>
            ))}
          </ul>
        </div>

        {/* CTA button */}
        <button
          onClick={handleStart}
          style={{
            background: 'var(--metro-yellow)',
            color: 'var(--navy)',
            border: 'none',
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: '1.1rem',
            fontWeight: 700,
            padding: '1rem 2.5rem',
            borderRadius: '12px',
            cursor: 'pointer',
            letterSpacing: '1px',
            animation: 'fadeIn 1s 1.2s both, pulse 2s 2.2s infinite',
            transition: 'transform 0.15s, box-shadow 0.15s',
            position: 'relative',
            overflow: 'hidden',
          }}
          onMouseEnter={e => {
            e.currentTarget.style.transform = 'scale(1.05)';
            e.currentTarget.style.boxShadow = '0 8px 30px rgba(252,224,62,0.4)';
          }}
          onMouseLeave={e => {
            e.currentTarget.style.transform = '';
            e.currentTarget.style.boxShadow = '';
          }}
          onMouseDown={e => { e.currentTarget.style.transform = 'scale(0.97)'; }}
          onMouseUp={e => { e.currentTarget.style.transform = ''; }}
          aria-label="Start the birthday experience"
        >
          🎫 Swipe your MetroCard
        </button>

        <p style={{
          color: 'rgba(255,255,255,0.3)',
          fontSize: '0.7rem',
          marginTop: '1.5rem',
          fontFamily: "'Space Mono', monospace",
        }}>
          25 stops · 1 journey · infinite love
        </p>
      </div>
    </div>
  );
}

function StarsBg() {
  const stars = React.useMemo(() =>
    Array.from({ length: 80 }, (_, i) => ({
      id: i,
      size: Math.random() * 3 + 1,
      left: Math.random() * 100,
      top: Math.random() * 100,
      dur: 2 + Math.random() * 4,
      delay: Math.random() * 3,
      opacity: 0.2 + Math.random() * 0.6,
    }))
  , []);

  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
      {stars.map(s => (
        <div
          key={s.id}
          style={{
            position: 'absolute',
            background: 'white',
            borderRadius: '50%',
            width: s.size,
            height: s.size,
            left: `${s.left}%`,
            top: `${s.top}%`,
            opacity: s.opacity,
            animation: `starFloat ${s.dur}s ${s.delay}s infinite ease-in-out`,
          }}
        />
      ))}
    </div>
  );
}
