import React, { useState } from 'react';
import IntroScreen from './components/IntroScreen.jsx';
import SubwayMap from './components/SubwayMap.jsx';
import StopModal from './components/StopModal.jsx';
import CassettePlayer from './components/CassettePlayer.jsx';
import { ToastContainer } from './components/effectsAll.js';
import { useEasterEggs } from './components/easterEggs.js';
import { STOPS } from './data/stops.js';

// View states
const VIEW = { INTRO: 'intro', MAP: 'map' };

export default function App() {
  const [view, setView] = useState(VIEW.INTRO);
  const [activeStop, setActiveStop] = useState(null); // null = modal closed
  const [visited, setVisited] = useState(new Set());

  // Wire up all easter eggs
  useEasterEggs();

  const openStop = (index) => {
    setActiveStop(index);
    setVisited(prev => new Set([...prev, index]));
  };

  const closeStop = () => setActiveStop(null);

  const goNext = () => {
    if (activeStop === null) return;
    if (activeStop < STOPS.length - 1) openStop(activeStop + 1);
    else closeStop();
  };

  const goPrev = () => {
    if (activeStop === null || activeStop === 0) return;
    openStop(activeStop - 1);
  };

  return (
    <>
      {/* ── Screens ── */}
      {view === VIEW.INTRO && (
        <IntroScreen onStart={() => setView(VIEW.MAP)} />
      )}

      {view === VIEW.MAP && (
        <SubwayMap
          visited={visited}
          onSelectStop={openStop}
          onGoToFinale={() => openStop(STOPS.length - 1)}
        />
      )}

      {/* ── Stop modal (shown over map) ── */}
      {activeStop !== null && view === VIEW.MAP && (
        <StopModal
          stopIndex={activeStop}
          onClose={closeStop}
          onNext={goNext}
          onPrev={goPrev}
        />
      )}

      {/* ── Floating cassette player (always visible after intro) ── */}
      {view === VIEW.MAP && <CassettePlayer />}

      {/* ── Global DOM hooks for confetti / toast ── */}
      <div id="confetti-root" style={{ position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 9999 }} />
      <ToastContainer />
    </>
  );
}
