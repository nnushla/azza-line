// ============================================================
//  ✏️  AZZA'S DATA — Edit everything in this file!
//  All personal details, photos, messages, and content live here.
//  The rest of the code reads from this file automatically.
// ============================================================

// ── FRIEND COUNCIL (Stop 4) ──────────────────────────────────
// Add up to 8 friends. Each has:
//   name: displayed name
//   role: their official title in the council
//   stat: a fun one-liner about them
//   emoji: fallback if no photo
//   color: background color for their avatar card
//   photo: path like "/images/friends/friend-1.jpg" or null for emoji fallback
export const FRIENDS = [
  {
    name: "Friend Name Here",         // ✏️ replace
    role: "Emotional Support",
    stat: "On call 24/7, never complains",
    emoji: "👑",
    color: "#fff0f8",
    photo: null,                      // ✏️ e.g. "/images/friends/friend-1.jpg"
  },
  {
    name: "Friend Name Here",         // ✏️ replace
    role: "Professional Yapper",
    stat: "Has never once been quiet",
    emoji: "🎙️",
    color: "#f0f4ff",
    photo: null,
  },
  {
    name: "Friend Name Here",         // ✏️ replace
    role: "Sends Memes at 3AM",
    stat: "1000+ memes sent, no regrets",
    emoji: "📱",
    color: "#f0fff4",
    photo: null,
  },
  {
    name: "Friend Name Here",         // ✏️ replace
    role: "Keeps Everyone Fed",
    stat: "Legendary cook, feeds the group",
    emoji: "🍱",
    color: "#fff8e1",
    photo: null,
  },
  {
    name: "Friend Name Here",         // ✏️ replace
    role: "Group Chat Instigator",
    stat: "Never a dull moment",
    emoji: "🔥",
    color: "#fff3e0",
    photo: null,
  },
  {
    name: "Friend Name Here",         // ✏️ replace
    role: "Accidental Therapist",
    stat: "Free sessions, deeply qualified",
    emoji: "🌙",
    color: "#f5f0ff",
    photo: null,
  },
];

// ── BANGS HALL OF FAME (Stop 1) ──────────────────────────────
// 5 eras of Azza's iconic bangs.
// photo: path like "/images/bangs/bangs-1.jpg" or null for emoji
export const BANGS_ERAS = [
  { era: "Pre-bangs",      rating: "4/10 hair",    emoji: "😶", photo: null },
  { era: "First Attempt",  rating: "6/10 iconic",  emoji: "😌", photo: null },
  { era: "The Awakening",  rating: "8/10 vision",  emoji: "😎", photo: null },
  { era: "The Signature",  rating: "10/10 art",    emoji: "💅", photo: null },
  { era: "Final Form",     rating: "∞/10 legend",  emoji: "🌟", photo: null },
];

// ── CONCERTS (Stop 14) ───────────────────────────────────────
// Memorable shows Azza has been to.
// photo: "/images/concerts/concert-1.jpg" or null
export const CONCERTS = [
  {
    show: "The concert she's still not over",     // ✏️ replace
    venue: "Add venue here",
    year: "2023",
    note: "Still thinks about this one regularly.",
    photo: null,
  },
  {
    show: "The one where she cried (deservedly)", // ✏️ replace
    venue: "Add venue here",
    year: "2022",
    note: "No shame. The music earned every tear.",
    photo: null,
  },
  {
    show: "The underground show nobody knew about", // ✏️ replace
    venue: "Some legendary small venue",
    year: "2024",
    note: "She was there before it blew up.",
    photo: null,
  },
];

// ── ALBUMS (Stop 19) ─────────────────────────────────────────
// Albums that defined Azza's taste.
// photo: "/images/albums/album-1.jpg" or null for emoji cover
export const ALBUMS = [
  {
    title: "Add album title here",              // ✏️ replace
    artist: "Artist name",
    year: "2022",
    note: "This one changed everything.",
    emoji: "🖤",
    photo: null,
  },
  {
    title: "The album she plays on repeat",     // ✏️ replace
    artist: "Artist name",
    year: "2023",
    note: "No skips. Not one.",
    emoji: "💜",
    photo: null,
  },
  {
    title: "Late night classics",               // ✏️ replace
    artist: "Artist name",
    year: "2021",
    note: "Reserved for emotional hours.",
    emoji: "🌙",
    photo: null,
  },
  {
    title: "Current obsession",                 // ✏️ replace
    artist: "Artist name",
    year: "2024",
    note: "She will make you listen.",
    emoji: "🔥",
    photo: null,
  },
];

// ── DEEP CUTS (Stop 10) ──────────────────────────────────────
// Songs Azza introduced you to that you still think about.
export const DEEP_CUTS = [
  {
    title: "Add song title here",               // ✏️ replace
    artist: "Artist she introduced you to",
    note: "This one permanently altered our brain chemistry.",
  },
  {
    title: "The song nobody had heard of",      // ✏️ replace
    artist: "But Azza had it on rotation first",
    note: "She told you about this before it blew up.",
  },
  {
    title: "The closing track",                 // ✏️ replace
    artist: "Of the album you need to hear",
    note: "Don't skip this one. Trust.",
  },
];

// ── PLAYLISTS (Stop 6) ───────────────────────────────────────
// Named playlists Azza has made or that define her.
export const PLAYLISTS = [
  {
    title: "Main Character Energy",
    songs: "23 songs",
    note: '"This one permanently altered our brain chemistry."',
    emoji: "⭐",
  },
  {
    title: "3AM No Thoughts",
    songs: "31 songs",
    note: '"The soundtrack to every late-night conversation."',
    emoji: "🌙",
  },
  {
    title: "Driving At Golden Hour",
    songs: "19 songs",
    note: '"This is the soundtrack to your main character era."',
    emoji: "🌅",
  },
  {
    title: "For When You Need to Cry",
    songs: "14 songs",
    note: '"We don\'t talk about this playlist but it\'s necessary."',
    emoji: "💧",
  },
];

// ── LOVE LETTERS (Stop 22) ───────────────────────────────────
// Messages from friends / entities. Add as many real ones as you want!
export const LOVE_LETTERS = [
  {
    from: "Your best friend",                   // ✏️ replace with real names
    msg: "You make every room better by being in it. I don't know what I'd do without you. Happy birthday, you absolute menace. 🤎",
  },
  {
    from: "Your music taste",
    msg: "Thank you for giving me a worthy vessel. Not everyone can handle this level of excellence.",
  },
  {
    from: "New York City",
    msg: "We see you. We know you. You belong here. Come back soon. — Love, NYC 🗽",
  },
  {
    from: "Everyone you've ever made a playlist for",
    msg: "We still listen. We think of you every time one of those songs plays. You have no idea how many people you've touched.",
  },
  {
    from: "Your brown friends 🤎",
    msg: "You are loved. You are seen. We are so proud of who you are. Happy 25th, babes.",
  },
  // ✏️ Add more messages here! Just copy the format above.
  // { from: "Real Friend Name", msg: "Their actual message to Azza." },
];

// ── FINALE MESSAGES (Stop 25) ────────────────────────────────
// Messages that fade in during the final stop.
export const FINALE_MESSAGES = [
  { from: "From your people",  msg: "You make us laugh louder than anyone." },
  { from: "From NYC",          msg: "The city is better when you're in it." },
  { from: "From the music",    msg: "Thank you for listening. Really listening." },
  { from: "From Mongolia",     msg: "You carry us with you. We couldn't be prouder." },
  // ✏️ Add real friend shoutouts here:
  // { from: "From [Name]", msg: "Their actual message." },
];

// ── MUSIC ORIGIN TIMELINE (Stop 2) ───────────────────────────
// Azza's music nerd origin story milestones.
export const MUSIC_TIMELINE = [
  { year: "2006", event: "Heard a song that absolutely destroyed her", icon: "🎵" },
  { year: "2010", event: "Made her first playlist. It was 4 hours long.", icon: "📋" },
  { year: "2015", event: "Started recognizing songs within 3 notes", icon: "⚡" },
  { year: "2019", event: "Became the group's official DJ", icon: "🎧" },
  { year: "2024", event: "Has taste so good it should be illegal", icon: "👑" },
  // ✏️ Add real Azza music milestones here
];

// ── HOT TAKES (Stop 15) ──────────────────────────────────────
// Azza's strong opinions. The more real these are, the better.
export const HOT_TAKES = [
  { take: "Has strong opinions about skip intros",             heat: "🌶🌶" },
  { take: "Judges people by their Spotify Wrapped",            heat: "🌶🌶🌶" },
  { take: "Albums should be listened to in order, always",     heat: "🌶🌶🌶🌶" },
  { take: "Add Azza's actual hot take here",                   heat: "🌶🌶🌶🌶🌶" },
  // ✏️ Add more real ones
];

// ── SPOTIFY PLAYLIST ─────────────────────────────────────────
// The embed URL for the cassette player.
export const SPOTIFY_EMBED_URL =
  "https://open.spotify.com/embed/playlist/469efWs3YtfmtFPSDfFaPU?utm_source=generator";
