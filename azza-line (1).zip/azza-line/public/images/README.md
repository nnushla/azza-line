# 📸 Images — Where to Put Your Photos

This folder holds all personal photos for the A-ZZA Line birthday card.
Drop images in the correct subfolder, then update the corresponding data file in `src/data/`.

---

## 📁 Folder Structure

### `/friends/`
Photos of Azza's Brown Friend Council members.
- Recommended size: **300×300px** (square, will be cropped to circle)
- Name them: `friend-1.jpg`, `friend-2.jpg`, etc.
- Or use any name and update `src/data/friends.js` to match.

### `/bangs/`
Photos for the Bangs Hall of Fame progression.
- Recommended size: **400×400px** (square)
- Name them: `bangs-1.jpg` through `bangs-5.jpg` (era 1 → 5)
- Update `src/data/bangs.js` to match.

### `/concerts/`
Concert photos / ticket stubs / memorable music moments.
- Recommended size: **600×400px** (landscape)
- Name them: `concert-1.jpg`, `concert-2.jpg`, `concert-3.jpg`
- Update `src/data/concerts.js` to match.

### `/albums/`
Album artwork or photos related to favorite albums.
- Recommended size: **400×400px** (square)
- Name them: `album-1.jpg` through `album-4.jpg`
- Update `src/data/albums.js` to match.

### `/mongolia/`
Photos for the Mongolian Pride section.
- Landscapes, cultural photos, personal family/heritage photos welcome.
- Name them: `mongolia-1.jpg` through `mongolia-6.jpg`
- Update `src/data/mongolia.js` to match.

---

## 💡 Tips

- Use `.jpg` or `.webp` for photos (smaller file size).
- Keep each image under **500KB** for fast loading.
- All images have graceful emoji fallbacks, so the site works even without photos.
- You can use free tools like [Squoosh](https://squoosh.app) to compress images.
