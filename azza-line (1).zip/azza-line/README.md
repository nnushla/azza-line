# 🚇 The A-ZZA Line
### A birthday experience for Azza's 25th

**25 stops. 1 journey. Infinite love.**

Built with React + Vite. Deploy in 5 minutes on Vercel or GitHub Pages.

---

## ✏️ Personalize it first

Everything you'll want to edit lives in **one file**:

```
src/data/azza.js
```

Open it and you'll find clearly labelled sections for:

| Section | What to edit |
|---|---|
| `FRIENDS` | Names, roles, stats, and photo paths for the Brown Friend Council |
| `BANGS_ERAS` | Captions and photo paths for the Bangs Hall of Fame |
| `CONCERTS` | Show names, venues, years, and photos |
| `ALBUMS` | Album titles, artists, and cover art |
| `DEEP_CUTS` | Songs Azza introduced you to |
| `PLAYLISTS` | Named playlists with descriptions |
| `LOVE_LETTERS` | Messages from friends (add real ones here!) |
| `FINALE_MESSAGES` | What fades in on the final stop |
| `MUSIC_TIMELINE` | Milestones in her music nerd origin story |
| `HOT_TAKES` | Her strong opinions |
| `SPOTIFY_EMBED_URL` | Already set — change if needed |

Every field has a `// ✏️ replace` comment next to it.

---

## 📸 Adding photos

Drop images in the right folder under `public/images/`:

```
public/images/
  friends/     → friend-1.jpg, friend-2.jpg …   (square, 300×300px)
  bangs/       → bangs-1.jpg … bangs-5.jpg       (square, 400×400px)
  concerts/    → concert-1.jpg …                 (landscape, 600×400px)
  albums/      → album-1.jpg … album-4.jpg       (square, 400×400px)
  mongolia/    → (optional, for atmosphere)
```

Then set the `photo` field in `src/data/azza.js`:
```js
photo: "/images/friends/friend-1.jpg",   // ← was null
```

If a photo isn't found or `photo` is `null`, an emoji shows automatically — the site never breaks.

> **Tip:** Keep images under 500KB each. Use [Squoosh](https://squoosh.app) to compress.

---

## 🚀 Deploy to Vercel (recommended, free)

**One-time setup:**

1. Push this repo to GitHub
2. Go to [vercel.com](https://vercel.com) → New Project
3. Import your GitHub repo
4. Vercel auto-detects Vite → click **Deploy**
5. Share the link with Azza 🎉

Every push to `main` auto-redeploys.

---

## 🚀 Deploy to GitHub Pages (also free)

1. In `vite.config.js`, add your repo name as the base:
   ```js
   export default defineConfig({
     plugins: [react()],
     base: '/your-repo-name/',  // ← add this
   })
   ```
2. Install the deploy package:
   ```bash
   npm install --save-dev gh-pages
   ```
3. Add to `package.json` scripts:
   ```json
   "predeploy": "npm run build",
   "deploy": "gh-pages -d dist"
   ```
4. Run:
   ```bash
   npm run deploy
   ```
5. In your GitHub repo → Settings → Pages → set source to `gh-pages` branch

---

## 💻 Run locally

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

---

## 🐣 Easter eggs (don't tell Azza)

| Trigger | What happens |
|---|---|
| Click the bodega cat 5× | `pspspspsps 🐾` |
| Type `I'M GAY` anywhere | Rainbow confetti + "We know. 🏳️‍🌈" |
| Type `BAGEL` anywhere | `+5 NYC credibility` |
| Double-click a 🥯 | Same as above |
| ↑↑↓↓←→←→BA (Konami code) | ULTIMATE MUSIC NERD MODE |
| Complete Gay Bingo (5 in a row) | Confetti + achievement banner |

---

## 📁 File structure

```
azza-line/
├── public/
│   ├── favicon.svg
│   └── images/
│       ├── README.md          ← photo size guide
│       ├── friends/           ← friend photos go here
│       ├── bangs/             ← bangs era photos
│       ├── concerts/          ← concert photos
│       ├── albums/            ← album art
│       └── mongolia/          ← optional atmosphere photos
├── src/
│   ├── data/
│   │   ├── azza.js            ← ✏️ EDIT THIS — all personal content
│   │   └── stops.js           ← the 25 stop definitions
│   ├── components/
│   │   ├── IntroScreen.jsx    ← opening screen with MetroCard button
│   │   ├── SubwayMap.jsx      ← the main map / stop list
│   │   ├── StopModal.jsx      ← all 25 stop contents
│   │   ├── CassettePlayer.jsx ← floating Spotify widget
│   │   ├── PhotoOrEmoji.jsx   ← smart photo/emoji fallback
│   │   ├── effects.js         ← confetti + toast
│   │   ├── effectsAll.js      ← re-exports + rainbow confetti
│   │   └── easterEggs.js      ← konami + typed triggers
│   ├── styles/
│   │   └── global.css         ← CSS variables + animations
│   ├── App.jsx                ← root component, wires everything
│   └── main.jsx               ← entry point
├── index.html
├── vite.config.js
└── package.json
```

---

## 💌 Made with love

This experience was built as a gift. Everything in it can be customized, extended, and made more personal. The code is yours to do whatever you want with.

Happy 25th, Azza. 🎂
